package com.example.catalog;

public interface Readable {
    public String printContents();
}
