package com.example.catalog;

public interface Searchable {
    public String getDisplayName();
    public String prepareSearchableString();
}
